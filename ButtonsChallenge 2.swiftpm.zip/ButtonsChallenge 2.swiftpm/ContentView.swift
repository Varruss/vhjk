//  Buttons Challenge
//
//  Created by Ben Button
//  Copyright © 2023 MobileMakersEdu. All rights reserved.

import SwiftUI

struct ContentView: View {
    
    @State var changeBackground: Bool = true
    @State var counter: Int = 0
    @State var lightBulbStatus: String = "On"
    @State var showAlert = false
    
    var body: some View {
        VStack(spacing: 40) {
            
            Group {
                Divider()
                Text("Buttons Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            //MARK: MVP
            
            HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 100) {
                Button("1") { 
                    print("Button #1 was Pressed")
                }
                .foregroundColor(.white)
                .font(.largeTitle)
                .background(
                    Rectangle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(.red)
                )
                Button(action: {print("Button #2 was pressed")}, label: {
                    Text("2")}) 
                .foregroundColor(.white)
                .font(.largeTitle)
                .background(
                    Rectangle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(.red))
            }
            
            
            
            
            //MARK: Stretch #1
            VStack{
                Button("Change Background")
                {
                    self.changeBackground.toggle()
                }
                
            } 
            .foregroundColor(.white)
            .font(.system(size: 20))
            .background(
                RoundedRectangle(cornerRadius: 15, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
                    .frame(width: 200, height: 50, alignment: .center)
                    .foregroundColor(.blue))
            .offset(x: 0, y: 30)
            
            
            
            
            
            
            //MARK: Stretch #2
            
            
            VStack{
                Button("\(counter)")
                {
                    counter = counter + 1
                }
            } .foregroundColor(.white)
                .font(.system(size: 20))
                .background(
                    Capsule()
                        .frame(width: 100, height: 50, alignment: .center)
                        .foregroundColor(.gray))
                .offset(x: 0, y: 30)
            
            
            
            
            //MARK: Stretch #3
            VStack{
                Button(action: {
                    self.showAlert = true
                }, label: {
                    Circle()
                        .frame(width: 100, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)   
                        .foregroundColor(.green)
                        .overlay(Image(systemName: "key.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 60)))
                        .shadow(radius: 10)
                })
                .alert(isPresented: $showAlert){Alert(title: Text(""), message: Text("Stretch #3 is complete"))
                }
            }.offset(x: 0, y: 50)
            
            
            //MARK: Stretch #4
            Button(action:
                    {
                if lightBulbStatus == "On"
                {
                    self.lightBulbStatus = "Off"
                }
                else{
                    self.lightBulbStatus = "On"
                }
            }
                   , label: {
                if lightBulbStatus == "On"
                {Image(systemName: "lightbulb.fill")
                        .foregroundColor(.yellow)
                    
                    Text("The Lightbulb is on")
                    
                        .foregroundColor(.yellow)
                    
                }
                
                else {
                    Image(systemName: "lightbulb.fill")
                        .foregroundColor(.white)
                    Text("Lightbulb is off")
                        .foregroundColor(.black)
                }
            })
            .offset(x: 0, y: 50)
            
            
            
            
            Group {
                
                Image("MobileMakersEduNB")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
                    .offset(x: 0, y: 100)
            }
            
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .background(changeBackground ? .white : .black)
    }
}

