import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Image Demo")
            Image("Tennis")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.blue)
            Image("volleyball")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.blue)
            Image(systemName: "trash")
                .resizable()
                .aspectRatio(contentMode: .fit)
           // Image(systemName: "figure.fall")
            //    .resizable()
            //    .aspectRatio(contentMode: .fit)
        }
        
    }
}
