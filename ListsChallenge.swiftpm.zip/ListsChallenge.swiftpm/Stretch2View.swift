import SwiftUI

struct Stretch2View: View {
    //MARK: Stretch #2 - Part II
    @State var people: [Person] = [
        Person(age: 26, name: "Billy"), 
        Person(age: 37, name: "Joe"), 
        Person(age: 19, name: "Colin")]
    
    
    
    var body: some View {
        //MARK: Stretch #2 - Part III
        
        List(people, id: \.self) { someone in 
            Text("Name: \(someone.name)")
                .font(.largeTitle)
            Text("Age: \(someone.age)")
                .font(.title3)
        }
        
        
        
    }
}

