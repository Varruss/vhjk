import SwiftUI

//MARK: Stretch #2 - Part I
struct Person: Hashable {
    var age : Int 
    var name: String 
}
