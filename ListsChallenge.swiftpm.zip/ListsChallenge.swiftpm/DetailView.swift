import SwiftUI

//MARK: Stretch #3 - Part III

struct DetailView: View {
    let name: String
    let age: Int
    var body: some View {
        VStack {
            List {
                Text("Name: \(name)")
                    .font(.largeTitle)
                Text("Age: \(age)")
                    .font(.title3)
            }
        }
    }
}
