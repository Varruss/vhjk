import SwiftUI

struct MVPView: View {
    //MARK: MVP - Part I
    @State var currencies: [String] = ["US Dollar", "Euro", "Mexican Peso", "Japanese Yen", "Bulgarian Lev"]
    
    var body: some View {
        VStack {
            Text("World Currencies")
            
            //MARK: MVP - Part II
            List(currencies, id: \.self) { c in
                Text(c)
            }
            
            
            
            
        }
    }
}

