import SwiftUI


struct Stretch3View: View {
    //MARK: Stretch #3 - Part I
    @State var people: [Person] = [
        Person(age: 26, name: "Billy"), 
        Person(age: 37, name: "Joe"), 
        Person(age: 19, name: "Colin")]
    
    var body: some View {
        //MARK: Stretch #3 - Part II
        
        NavigationStack {
            List(people, id: \.self) { someone in
                NavigationLink {
                    DetailView(name: someone.name, age: someone.age)
                    
                } label: {
                    Text(someone.name)
                }
            }
            .navigationTitle("Select a Name")
        }
    }
}

