import SwiftUI

struct Stretch1View: View {
    //MARK: Stretch #1 - Part I
    @State var writtenAnimal = ""
    @State var storeAnimals: [String] = []
    
    
    
    
    var body: some View {
        VStack {
            //MARK: Stretch #1 - Part II
            TextField("Write your animal", text: $writtenAnimal)
                .textFieldStyle(.roundedBorder)
                .multilineTextAlignment(.center)
                .frame(width: 400)
                .onSubmit() {
                    storeAnimals.append(writtenAnimal)
                }
            List {
                ForEach(0..<storeAnimals.count, id: \.self) { animal in
                    Text(storeAnimals[animal])
                }
            }
        }
    }
}

