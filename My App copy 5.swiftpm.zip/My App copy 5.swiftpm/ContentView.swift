import SwiftUI

struct ContentView: View {
    @State var items: [String] = ["Milk", "Carrots", "Graham Crackers", "Marshmallows", "Chocolate"]
    @State var add = ""
    @State var items2: [ShoppingItem] = [
        ShoppingItem(name: "Bananas", quantity: 5), 
        ShoppingItem(name: "Pineapples")]
    var body: some View {
        
        List{
            Text("What you buying")
            Text("V-Bucks")
            Text("Protein Powder")
            Text("Pizza")
            Text("Eggs")
            Text("An Apple")            
        }
        Divider()
        HStack{
            TextField("Add an Item", text: $add)
                .frame(width: 200)
                .textFieldStyle(.roundedBorder)
            Button(action: {
                items.append(add)
            }, label: {
                Image(systemName: "plus.square.fill")
            })
            Button(action: {
                items.remove(at: items.count - 1)
            }, label: {
                Image(systemName: "minus.square.fill")            })
        }
        .multilineTextAlignment(.center)
        List(items, id: \.self) { currentItem in 
            Text(currentItem)
        }
        List(items2, id: \.self) { currentItem in
            Text(currentItem.name)
                .font(.largeTitle)
            Text("Quantity: \(currentItem.quantity ?? 1)")
                .font(.title3)
        }
    }
}
