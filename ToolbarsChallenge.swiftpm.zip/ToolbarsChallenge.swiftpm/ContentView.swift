import SwiftUI

struct ContentView: View {
    var timer: Timer {
        //MARK: Stretch #3 - Part I
        Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) {_ in
            progressTime += 1
        }
    }

    var minutes: String {
        //MARK: Stretch #3 - Part II
        let time = (progressTime/6000) % 60
        return time < 10 ? "0\(time)" : "\(time)"
    }
    
    var seconds: String {
        //MARK: Stretch #3 - Part III
        let time = (progressTime/100) % 60
        return time < 10 ? "0\(time)" : "\(time)"
    }
    
    //MARK: Stretch #3 - Part IV
    
    var hundrethSeconds: String {
        let time = progressTime % 100
        return time < 10 ? "0\(time)" : "\(time)"

    }
    
    
    @State private var progressTime = 0
    @State var myTimer:Timer?

    var body: some View {
        HeaderView()
        NavigationStack {
            //MARK: Stretch #3 - Part V
            Text("\(minutes):\(seconds):\(hundrethSeconds)")
                .font(.system(size: 100))
                .toolbar { 
                    //MARK: MVP
                    ToolbarItem(placement: .navigationBarLeading) { 
                        Button(action: {
                            myTimer = timer 
                        }, label: {
                            Text("Start")
                        })
                    }
                    //MARK: Stretch #1
                    ToolbarItem(placement: .navigationBarTrailing) { 
                        Button(action: {
                            myTimer?.invalidate() 
                        }, label: {
                            Text("Stop")
                        })
                    }
                                       
                    
                    
                    //MARK: Stretch #2
                    
                    ToolbarItem(placement: .bottomBar) { 
                        Button(action: {
                            progressTime = 0 
                        }, label: {
                            Text("Reset")
                        })
                    }
                    
                    
                    
                }
        }
        FooterView()
    }
}
