import SwiftUI

@main
struct MyApp: App {
    @State var MyStarVisits = StarTravel()
    var body: some Scene {
        WindowGroup {
            ContentView(MyStarVisits: $MyStarVisits)
        }
    }
}
