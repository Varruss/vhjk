import SwiftUI

struct FirstStarView: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        Image("\(myStarVisits.firstStarName)")
            .resizable()
            .scaledToFill()
        TextField("Second Star to visit", text: $myStarVisits.SecondStarName)
            .textFieldStyle(.roundedBorder)
        NavigationLink("Go To Second Star") {
            SecondStarView(myStarVisits: $myStarVisits)
        }
    }
}


