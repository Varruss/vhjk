import SwiftUI


struct SummaryView: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        Text("You first visited \(myStarVisits.firstStarName)")
        Text("You first visited \(myStarVisits.firstStarName.count) light years")
        Divider()
        Text("You second visited \(myStarVisits.SecondStarName)")
        Text("You next visited \(myStarVisits.SecondStarName.count) light years")

        }
    }


