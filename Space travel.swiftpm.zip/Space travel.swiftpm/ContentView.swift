import SwiftUI

struct ContentView: View {
    @Binding var MyStarVisits: StarTravel
    var body: some View {
        NavigationView {
            
            VStack {
                TextField("First Star to Visit", text: $MyStarVisits.firstStarName)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                    .disableAutocorrection(true)    
                NavigationLink("Go to First Star") {
                    FirstStarView(myStarVisits: $MyStarVisits)  
                }
            }
            .navigationTitle("InterGalactic Traveler")
            .frame(maxWidth: .infinity,maxHeight: .infinity)
            .background(
                Image("Space")
                    .resizable()
                    .scaledToFill()
            )
        }
        .navigationViewStyle(.stack)
    }
}
