import SwiftUI
class StarTravel {
    var firstStarName: String
    var SecondStarName: String
    
    init() {
        firstStarName = ""
        SecondStarName = ""
    }
}
