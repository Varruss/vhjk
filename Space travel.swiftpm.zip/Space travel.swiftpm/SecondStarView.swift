import SwiftUI

struct SecondStarView: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        Image("\(myStarVisits.SecondStarName)")
            .resizable()
            .scaledToFill()
        TextField("Second Star to visit", text: $myStarVisits.SecondStarName)
            .textFieldStyle(.roundedBorder)
            .padding()
            .disableAutocorrection(true)
        NavigationLink("Go To Summary") {
            SummaryView(myStarVisits: $myStarVisits)
        }
    }
}

