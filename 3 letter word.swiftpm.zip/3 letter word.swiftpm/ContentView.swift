import SwiftUI

struct ContentView: View {
    let letters =
    ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    @State var word = ["0","1","2"]
    @State var letterPosition = 0
    @State var showAlert = false
    var body: some View {
        HStack(spacing: 20) {
            ForEach(0..<word.count, id: \.self) { value in
                Text(word[value])
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 75, alignment: .center)
                    .background(.white)
                    .foregroundColor(.purple)
                    .font(.largeTitle)
            } 
        }
        Divider()
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 50))], content: {
                ForEach(letters, id: \.self) { item in
                    Text(item)
                        .onTapGesture {
                            word[letterPosition] = item
                            letterPosition += 1
                            if letterPosition == word.count {
                                showAlert = true
                            }
                        }
                }
            })
        Divider()
            Button("Reset") {
                showAlert.toggle()
            }
            .alert("Resetting", isPresented: $showAlert) { 
                Button("Okay") {
                    letterPosition = 0
                    for i in 0..<word.count {
                        word[i] = "?"
                    }
                }  
            }
            .frame(width: 300, height: 75, alignment: .center)
            .background(.red)
            .foregroundColor(.purple)
            .font(.largeTitle)
            .clipShape(RoundedRectangle(cornerRadius: 20))
        Divider()
        }
    }

