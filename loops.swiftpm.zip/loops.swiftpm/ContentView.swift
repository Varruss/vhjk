import SwiftUI

struct ContentView: View {
    @State var myOutput = ""
    @State var favoriteResturant = ["Olive Garden", "BlackFin", "Cooper's Hawk"]
    @State var fruit = ["Strawberies", "Raspberries", "Peaches", "Tangerines"]
    @State var bands = ["ACDC", "Rage Against the Machine", "Korn"]
    @State var pizzaToppings = ["Pineapple", "Olives", "Sasauges", "Pepperoni"]
    @State var contact = [
        "Name" : "Colin",
        "Nickname" : "C-Money",
        "Address" : "801 Kensington",
        "Number" : "555-555-5555",
        "Zipcode" : "60056"
    
    ]
    var body: some View {
        Text(myOutput)
            .font(.largeTitle)
        VStack(spacing: 20) {
            Button("Array 1") {
                var output = ""
                for item in fruit {
                    output += "\(item) \n"
                }
                myOutput = output
            }
            Divider()
            Button("Array 2") {
                var output = ""
                for i in 0...2 {
                    output += "\(favoriteResturant[i])\n"
                }
                myOutput = output
            }
            Divider()
            Button("Array 3") {
                var output = ""
                for i in 0..<2 {
                    output += "\(bands[i])\n"
                }
                myOutput = output
            }
            Button("Array 4") {
                var output = ""
                for i in 0..<pizzaToppings.count {
                    output += "\(pizzaToppings[i])\n"
                }
                myOutput = output
            }
            Button("Dictionary") {
                var output = ""
                for (key,value) in contact {
                    output += "\(key): \(value) \n" 
                    
                }
                myOutput = output
            }
        }
        .font(.largeTitle)
        
    }
}
