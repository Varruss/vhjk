import SwiftUI

struct ContentView: View {
    //MARK: Stretch #2 - Part II
    @State var coinsArray = [Coin(value: 1, name: "Penny"), 
                             Coin(value: 5, name: "Nickel"),
                             Coin(value: 10, name: "Dime"),
                             Coin(value: 25, name: "Quarter"),
                             Coin(value: 50, name: "Half-Dollar")]
    
    
    
    var body: some View {
        HeaderView()
        Spacer()
        Text("MVP Works")
        //MARK: MVP - Part II
            .modifier(BorderedCaption())
        
        
        
        
        //MARK: Stretch #1 - Part II
        MapView()
            .frame(width: 300, height: 200)        
        
        
        //MARK: Stretch #2 - Part III    
        List(coinsArray) { item in 
            Text(item.name)
                .font(.title3)
            Text("Value: \(item.value)¢")
        }
        
        
        
        
        //MARK: Stretch #3 - Part II
        TrapezoidView()
            .foregroundColor(.blue)
            .padding(20)
        
        
        
        
        Spacer()
        FooterView()
    }
}
