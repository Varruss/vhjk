import SwiftUI

//MARK: MVP - Part I
struct BorderedCaption: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.title)
            .padding(10)
            .frame(width: 180)
            .foregroundColor(Color.blue)
            .background(RoundedRectangle(cornerRadius: 55))
            
    }
}
