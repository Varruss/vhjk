import SwiftUI

//MARK: Stretch #2 - Part I
struct Coin: Identifiable {
    let id = UUID()
    let value: Int
    let name: String
}
