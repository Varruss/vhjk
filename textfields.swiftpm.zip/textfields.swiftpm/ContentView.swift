import SwiftUI

struct ContentView: View {
    @State var nameTextFieldText = ""
    @State var number = 0
    var body: some View {
        VStack {
            Text("Text Fields")
                .font(.largeTitle)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            TextField("Enter Name", text: $nameTextFieldText)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .multilineTextAlignment(.center)
                .padding()
            Text(nameTextFieldText)
                .font(.title)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .padding()
            Button(action: {
                if let enteredString = Int(nameTextFieldText){
                    print("entered text is an integer: \(enteredString)")
                }
                else {
                    print("Entered text is NOT an integer: \(nameTextFieldText)")
                }
            }
                   ,label: {
                Text("Using button")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            })
            TextField("Enter Number Here", value: $number, format: .number)
                .multilineTextAlignment(.center)
                .textFieldStyle(.roundedBorder)
                .padding()
            Text("The Number entered is: \(number)")
        }
    }
}
