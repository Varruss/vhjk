import SwiftUI

struct Stretch2View: View {
    var body: some View {
        //MARK: Stretch #2
    
            NavigationView(content: {
                VStack{
                
            
                NavigationLink { 
                    Image("soullookcat")
                        .resizable()
                        .frame(width: 400, height: 400)
                } label: { 
                    Image(systemName: "person.fill.turn.right")
                        .resizable()
                        .frame(width: 200, height: 200)
                } 
                .padding(50)
                NavigationLink { 
                    Image("yawngorilla")
                        .resizable()
                        .frame(width: 400, height: 400)
                } label: { 
                    Image(systemName: "questionmark.folder.ar")
                        .resizable()
                        .frame(width: 200, height: 200)
                } 
                .padding(50)
                    }
            })
        
    }
    
}
