import SwiftUI

struct MVPView: View {
    var body: some View {
        VStack {
            
            //MARK: MVP - Part V
            BlueView()
            RedView()
            
            
            
        }
    }
}

