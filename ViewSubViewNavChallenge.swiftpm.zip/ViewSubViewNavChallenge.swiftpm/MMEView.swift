import SwiftUI

struct MMEView: View {
    var body: some View {
        Text("Views, SubViews & Navigation\nChallenge")
            .multilineTextAlignment(.center)
            .font(.title)
    }
}

