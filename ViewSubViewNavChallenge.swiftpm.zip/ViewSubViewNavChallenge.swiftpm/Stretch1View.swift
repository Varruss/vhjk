import SwiftUI

struct Stretch1View: View {
    var body: some View {
        //MARK: Stretch #1 - Part II
        VStack{
            HStack{
                S1R(L1:"X", BackG: .cyan)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"X", BackG: .red)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"O", BackG: .red)
                
            }
            Text("-----------------------------------------------")
            HStack{
                S1R(L1:"X", BackG: .cyan)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"O", BackG: .red)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"X", BackG: .red)
                
            }
            Text("-----------------------------------------------")
            HStack{
                S1R(L1:"X", BackG: .cyan)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"O", BackG: .red)
                Text("----------")
                    .rotationEffect(.degrees(90))
                S1R(L1:"X", BackG: .red)
                
            }
        }
        
    }
}

//MARK: Stretch #1 - Part I

struct S1R: View {
    @State var L1: String
    @State var BackG: Color

    var body: some View {
        ZStack {
            HStack{
                Text(L1)
            }
        }
        .frame(width: 35, height: 35, alignment: .center)
        .background(BackG)
    }
}

