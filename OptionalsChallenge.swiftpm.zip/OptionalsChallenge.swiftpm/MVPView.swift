import SwiftUI

struct MVPView: View {
    @State var number1: Int?
    @State var number2: Int?
    @State var answer: Int = 0
    
    var body: some View {
        
        //MARK: MVP
        VStack{
            Button(action: {
                Calculate()
            }, label: {
                Text("Calculate")
            })
            HStack{
                TextField("Write a number", value: $number1, format: .number)
                Text("+")
                TextField("Write a number", value: $number2, format: .number)
            }
            .textFieldStyle(.roundedBorder)
            .frame(width: 400)
            Text("Sum: \(answer)")
               
        }
         .multilineTextAlignment(.center)
    }
    func Calculate() {
        answer = number1! + number2!
    }
}

