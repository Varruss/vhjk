import SwiftUI

struct Stretch3View: View {
    @State var number1: Int?
    @State var number2: Int?
    @State var answer: Int = 0
    @State var presentAlert = false
    @FocusState private var focusedField: String?
    
    var body: some View {
        
        //MARK: Stretch #3
        VStack{
            Button(action: {
                Calculate()
                Alert()
            }, label: {
                Text("Calculate")
            })
            HStack{
                TextField("Write a number", value: $number1, format: .number)
                Text("X")
                TextField("Write a number", value: $number2, format: .number)
            }
            .textFieldStyle(.roundedBorder)
            .frame(width: 400)
            Text("Product: \(answer)")
            
        }
        .multilineTextAlignment(.center)
        .alert("You did not enter a number in both boxes", isPresented: $presentAlert) {
            Button("Try again", role: .cancel) { }
        }
    }
    func Calculate() {
        answer = (number1 ?? 1) * (number2 ?? 1)
    }
    func Alert() {
        guard let _ = number1 else { return presentAlert = true}
        guard let _ = number2 else { return presentAlert = true}
        }
    }




