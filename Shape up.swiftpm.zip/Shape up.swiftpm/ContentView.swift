import SwiftUI

struct ContentView: View {
    var body: some View { 
        Text("Jaedan may hurt somebody tonight")
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .foregroundColor(.white)
            .background(Circle()
                .foregroundColor(.green)
                .background(.pink))
        
        Circle()
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        Rectangle()
            .padding(100)
        Ellipse()
            .fill(.purple)
        RoundedRectangle(cornerRadius: 200, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/)
            .fill(.pink)
            .opacity(0.5)
        
        
    }
}
