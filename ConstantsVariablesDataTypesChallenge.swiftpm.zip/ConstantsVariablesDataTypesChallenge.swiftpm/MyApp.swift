//  ConstantsVariablesDataTypes Challenge
//
//  Created by Dr. Datatype
//  Copyright © 2023 MobileMakersEdu. All rights reserved.

import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
