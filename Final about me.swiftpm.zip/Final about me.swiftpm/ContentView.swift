import SwiftUI

struct ContentView: View {
    @State private var Myself = false
    @State private var ImageMe = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            ZStack{
                VStack(alignment: .center) {
                    Button("About Me ☻ ")
                    {
                        Myself.toggle()
                    }   
                    .font(.system(size: 30))
                    .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                    
                    if Myself {
                        Text("Jonas Gregory \nClass of 2026 \n I'm Left Handed")
                            .font(.system(size: 20))
                            .multilineTextAlignment(.center)
                            .rotationEffect(.degrees(32), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .offset(x: 40, y: 24)
                    }
                }
            }
            .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .position(x: 180, y: 50)
            .offset(x: -80, y: 40)
            .rotationEffect(.degrees(-32))
            ZStack{
                VStack(alignment: .center) {
                    Button("Image of Me") 
                    {
                        ImageMe.toggle()
                    }
                    .font(.system(size: 30))
                    .foregroundColor(.red)
                    .rotationEffect(.degrees(50), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    if ImageMe {
                        Image("Me")
                            .resizable()
                            .frame(width: 200, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .border(.red, width: 5)
                            .offset(x: 0, y: 55)
                    }   
                }
                .offset(x: 0, y: 30)
            }        
            .position(x: 300, y: 80)
            .frame(width: 400, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            ZStack{
                VStack(alignment: .center) {
                    Image("589")
                        .resizable()
                        .frame(width: 500, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .mask(
                            Text("About Me")
                                .font(.system(size:72))
                        )
                        .position(x: 225, y: -485)                         .brightness(0.15)
                }
            }
            ZStack{
                Circle()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.cyan)
                VStack{
                    Rectangle()
                        .strokeBorder(
                            AngularGradient(gradient: Gradient(colors: [.red, .yellow, .green, .blue, .purple, .red]), center: .center, startAngle: .zero, endAngle: .degrees(360)),
                            lineWidth: 50
                        )
                        .frame(width: 200, height: 200)              
                }
            }
            .offset(x: 0, y: -40)
        }
    }
}


