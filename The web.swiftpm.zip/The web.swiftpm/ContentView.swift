import SwiftUI

struct ContentView: View {
  @State var nealUrl = URL(string:"https://neal.fun/")!
    var body: some View {
        Link("Go to Neal", destination: nealUrl)
        Spacer()
        Link(destination: /*@START_MENU_TOKEN@*/URL(string: "https://www.apple.com")!/*@END_MENU_TOKEN@*/, label: {
            Image(systemName: "apple.logo")
            Text("Apple")
        })
    }
}
