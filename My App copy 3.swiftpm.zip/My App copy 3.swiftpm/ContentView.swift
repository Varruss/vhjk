import SwiftUI

struct MyView: View {
    var body: some View {
        VStack {
            Text("My View")
        }
    }
}
