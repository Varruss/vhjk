import SwiftUI

struct AdjectiveView: View {
    @EnvironmentObject var model: Model
    var body: some View {
        VStack{
            Text("Choose an Adjective")
                .font(Font.custom(".", size: 40))
                .foregroundStyle(.blue)
                .offset(x: 0, y: 50)
            TextField("", text: $model.enteredadjective)    .autocorrectionDisabled()
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 50)
                .textFieldStyle(.roundedBorder)
                .padding(50)
            NavigationLink(destination: { 
                FinalView()
            }, label: { 
                Text("Now let's see what you wrote") 
                    .font(Font.custom(".", size: 20))
                    .foregroundStyle(.white) 
                    .background(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                        .frame(width: 300, height: 50)
                        .foregroundColor(.indigo))
            })        
        }
        .multilineTextAlignment(.center)
    }
}
