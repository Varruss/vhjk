import SwiftUI

struct Start2View: View {
    @EnvironmentObject var model: Model
    var body: some View {
        VStack {
            Spacer()
            NavigationView {
                VStack {
                    NavigationLink(destination: { 
                        NounView()
                    }, label: { 
                        Text("Let Us Begin our Adventure") 
                            .font(Font.custom(".", size: 25))
                            .foregroundStyle(.white)
                            .background(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                .frame(width: 350, height: 50)
                                .foregroundColor(.indigo))
                    })
                    
                    
                }
            }
            .navigationBarBackButtonHidden()
            Spacer()    
        }
        .navigationViewStyle(.stack)
    }
}
