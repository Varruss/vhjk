import SwiftUI

class Model: ObservableObject {
    //function to reset game and a function where you're going to make your story. Oh, and C Money
    @Published var enterednoun = ""
    @Published var enteredverb = ""
    @Published var enteredadjective = ""
    init(enterednoun: String = "", enteredverb: String = "", enteredadjective: String = "") {
        self.enterednoun = enterednoun
        self.enteredverb = enteredverb
        self.enteredadjective = enteredadjective
    }
    func clear() {
        enterednoun = ""
        enteredverb = ""
        enteredadjective = ""
    }
    func random()-> String {
        let randomInt = Int.random(in: 1...3)
        if randomInt == 1 {
            return "C-Money \(enteredverb)s the \(enteredadjective) \(enterednoun) into the truck" 
        }
        else if randomInt == 2 {
            return "The \(enteredadjective) \(enterednoun) is on a run when a fabulous C-Money \(enteredverb)s"
        }
        else {
            return "Right about now, the \(enteredadjective) C-Money was coding when a \(enterednoun) \(enteredverb)s"
        }
    }
}
