import SwiftUI

struct FinalView: View {
    @EnvironmentObject var model: Model
    @State var find = ""
    @State var replace = ""
    @State var wordistrue = false
    @State var wordisfalse = false
    
    var body: some View {
        VStack{
            Spacer()
            Text(model.random())
                .font(Font.custom(".", size: 40))
                .foregroundStyle(.white)
                .padding()
            Button(action: {
                model.clear()
            }, label: {
                Text("Clear all")
            })
            Spacer()          
            NavigationLink(destination: { 
                Start2View()
            }, label: { 
                Text("Now do it all again") 
                    .font(Font.custom(".", size: 20))
                    .foregroundStyle(.white) 
                    .background(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                        .frame(width: 200, height: 50)
                        .foregroundColor(.indigo))
            })
            Spacer() 
            Text("Check if a letter is here ")
            TextField("letter", text: $find)
                .autocorrectionDisabled(true)
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                .multilineTextAlignment(.center)
                .textFieldStyle(.roundedBorder)
            Button(action: {
                if model.random().contains(find) {
                    wordistrue = true
                }
                else {
                    wordisfalse = true
                }
            }, label: {
                Text("Find")
            })
            .alert("Important message", isPresented: $wordistrue) {
                
                Text("It's Here😃")
                
                Button("OK", role: .cancel) { }
            }
            .alert("Important message", isPresented: $wordisfalse) {
                
                Text("It isn't here😔")
                
                Button("OK", role: .cancel) { }
            }
            .multilineTextAlignment(.center)
            Spacer()
        }
    }
}
