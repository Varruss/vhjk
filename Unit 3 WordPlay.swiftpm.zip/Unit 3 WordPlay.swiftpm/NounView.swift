import SwiftUI

struct NounView: View {
    @EnvironmentObject var model: Model
    var body: some View {
        VStack{
            Text("Choose a noun")
                .font(Font.custom(".", size: 40))
                .foregroundStyle(.blue)
                .offset(x: 0, y: 50)
            TextField("", text: $model.enterednoun)  
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 50)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
                .padding(50)
            NavigationLink(destination: { 
                VerbView()
            }, label: { 
                Text("Now Pick a verb") 
                    .font(Font.custom(".", size: 20))
                    .foregroundStyle(.white) 
                    .background(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                        .frame(width: 200, height: 50)
                        .foregroundColor(.indigo))
            })        
        }
        .multilineTextAlignment(.center)
    }
}
