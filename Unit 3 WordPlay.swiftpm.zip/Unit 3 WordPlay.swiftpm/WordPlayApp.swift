import SwiftUI

@main
struct WordPlayApp: App {
    @StateObject var model = Model() 
    
    
    var body: some Scene {
        WindowGroup {
            StartView()
                .environmentObject(model)
        }
    }
}
