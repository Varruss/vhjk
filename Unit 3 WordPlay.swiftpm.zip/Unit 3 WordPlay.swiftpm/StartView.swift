import SwiftUI

struct StartView: View {
    @EnvironmentObject var model: Model
    var body: some View {
        VStack {
            Text("Welcome to The Worldplay")
                .font(Font.custom("Times New Roman", size:50))
                .foregroundStyle(.red)
                .bold()
            Spacer()
            NavigationView {
                VStack {
                    NavigationLink(destination: { 
                        NounView()
                    }, label: { 
                        Text("Let Us Begin our Adventure") 
                            .font(Font.custom(".", size: 25))
                            .foregroundStyle(.white)
                            .background(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                .frame(width: 350, height: 50)
                                .foregroundColor(.indigo))
                    })
                    
                    
                }
            }
            Spacer()    
        }
        .navigationViewStyle(.stack)
    }
}
