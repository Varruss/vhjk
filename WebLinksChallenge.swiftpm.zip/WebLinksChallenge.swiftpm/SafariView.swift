import SwiftUI
import SafariServices

//MARK: Stretch #2 - Part I

    struct SafariView: UIViewControllerRepresentable {
        let storeURL: URL
        func makeUIViewController(context: Context) -> some UIViewController {
                return SFSafariViewController(url: storeURL)
        }
        func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        }
}
