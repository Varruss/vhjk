import SwiftUI
import WebKit

//MARK: Stretch #3 - Part I

struct WebView: UIViewRepresentable {   
    let URL: URL
    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }
    func updateUIView(_ webView: WKWebView, context: Context) {
        let request = URLRequest(url: URL)
        webView.load(request)
    }
}
