import SwiftUI

struct ContentView: View {
    let basePay = 500
    @State var commisionPay = 0
    @State var totalPay = 0
    var body: some View {
        HStack {            
            VStack(alignment: .trailing, spacing: 30) {                
                Text("Base Pay")
                Text("Commision Pay")
                Text("Total Pay") 
            }
            VStack(alignment: .leading, spacing: 30) {
                Text(String(basePay)) 
                TextField("Enter Commision", value: $commisionPay, format: .currency(code: "USD") )
                    .onSubmit {
                        totalPay = basePay + commisionPay
                    }
                Text(String(totalPay))
            }
            Button(action: {
                clear()
            },
                   label: {
                Text("Clear")
            })
           // Button(<#T##title: StringProtocol##StringProtocol#>, action: <#T##() -> Void#>)
        }
        .padding()
    }
  
    func clear (){
        totalPay = 0
        commisionPay = 0
    }
}
