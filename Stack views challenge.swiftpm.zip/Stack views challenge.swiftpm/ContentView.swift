import SwiftUI

struct ContentView: View {   
    var body: some View {
        ZStack {
            VStack{
                Text("0") 
                    .font(.system(size:100))       
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing) 
                    .offset(x: -39, y: 105)
                HStack{
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .overlay(
                            Text("AC")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .overlay(
                            Text("+/-")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .overlay(
                            Text("%")
                                .foregroundColor(.black)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("÷")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                }
                HStack{
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("7")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("8")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("9")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("X")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                }
                HStack{
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("4")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)                        
                        .overlay(
                            Text("5")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("6")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("-")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                }
                HStack{
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("1")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("2")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("3")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("+")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                }
                HStack{
                    Capsule()
                        .frame(width: 208, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text("0")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                                .frame(width: 200, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                                .offset(x: 35, y: 0)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.gray)
                        .opacity(0.2)
                        .overlay(
                            Text(".")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                    Circle()
                        .frame(width: 100, height: 100, alignment: .center)
                        .foregroundColor(Color.orange)
                        .overlay(
                            Text("=")
                                .foregroundColor(.white)
                                .font(.largeTitle)
                        )
                }
            } 
        }
    }
    
}
