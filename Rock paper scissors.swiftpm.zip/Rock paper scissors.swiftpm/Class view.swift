import SwiftUI

class Object: ObservableObject {
    @Published var final: String
    @Published var opponent: String
    init() {
        final = ""
        opponent = ""
    }
    func random() {
        @State var ranInt = Int.random(in: 1...3)
        if ranInt == 1 {
            opponent = "🪨"
        }
        else if ranInt == 2 {
            opponent = "🗒"  
        }
        else {
            opponent = "✂️"
        }
    }
}
class Scores: ObservableObject {
    @Published var winScore: Int
    @Published var drawScore: Int
    @Published var loseScore: Int
    init() {
        winScore = 0
        drawScore = 0
        loseScore = 0
    }
}
