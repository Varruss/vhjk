import SwiftUI

struct ContentView: View {
    @StateObject var choice = Object()
    @EnvironmentObject var score: Scores
    @State var isShowingRockView = false
    @State var isShowingPaperView = false
    @State var isShowingScissorView = false
    var body: some View {
        NavigationStack {
            Text("Welcome to Rock Paper Scissors")
                .font(.title2)
                .padding(20)
            Text("Score: \n Wins: \(score.winScore) Draws: \(score.drawScore) Losses: \(score.loseScore)")
                .multilineTextAlignment(.center)
            VStack {
                
                Spacer()
                HStack(spacing: 30) {
                    Button(action: {
                        choice.final = "🪨"
                        choice.random()
                        isShowingRockView = true
                    }, label: {
                        Text("🪨")
                            .font(.system(size: 60))
                    })
                    .navigationDestination(isPresented: $isShowingRockView) {
                        FinalView()
                            .environmentObject(choice)
                    }
                    Button(action: {
                        choice.final = "🗒"
                        choice.random()
                        isShowingPaperView = true
                    }, label: {
                        Text("🗒")
                            .font(.system(size: 60))
                    })
                    .navigationDestination(isPresented: $isShowingPaperView) {
                        FinalView()
                            .environmentObject(choice)
                    }
                    Button(action: {
                        choice.final = "✂️"
                        choice.random()
                        isShowingScissorView = true
                    }, label: {
                        Text("✂️")
                            .font(.system(size: 60))
                    })
                    .navigationDestination(isPresented: $isShowingScissorView) {
                        FinalView()
                            .environmentObject(choice)
                    }
                    
                }
                
                Spacer()
                Link("Rules of this game(link)", destination: URL(string: "https://www.thegeniusofplay.org/genius/play-ideas-tips/play-ideas/rock-paper-scissors.aspx?WebsiteKey=f24671dc-3a61-4dfa-854c-b2d74801f627")!)
                    .offset(CGSize(width: 0.0, height: -70.0))
                    .foregroundStyle(.cyan)
                Button(action: {
                    score.drawScore = 0
                    score.winScore = 0
                    score.loseScore = 0
                }, label: {
                    Text("Reset The Scores")
                        .foregroundStyle(.cyan)
                })
                .offset(CGSize(width: 0.0, height: -40.0))
            }
        }
        .navigationBarBackButtonHidden()
    }          
}
