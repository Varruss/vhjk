import SwiftUI

@main
struct MyApp: App {
    @StateObject var score = Scores()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(score)
        }
    }
}
