import SwiftUI

struct FinalView: View {
    @EnvironmentObject var choice: Object
    @StateObject var score = Scores()
    @State var output = ""
    @State var animationAmount: CGFloat = 0
    var body: some View {
        VStack(spacing: 20){
            Text("Your choice is \(choice.final)")
                .foregroundStyle(.white)
                .onAppear(perform: {
                    whoWin()
                    animationAmount += 360
                })
            Text("You opponent chose \(choice.opponent)")
                .foregroundStyle(.white)
            Text(output)
                .foregroundStyle(.white)
            NavigationLink("Lets keep going", destination: ContentView()
               .environmentObject(score))
            .foregroundStyle(.cyan)
        }
        .font(.system(size: 30))
        .navigationBarBackButtonHidden()
        .rotationEffect(Angle(degrees: animationAmount))
        .animation(.default,value: animationAmount)
    }
    func whoWin() {
        if choice.final == "🪨" {
            if choice.opponent == "🪨" {
                output = "It is a draw"
                score.drawScore += 1
            }
            if choice.opponent == "🗒" {
                output = "You lose wamp wamp"
                score.loseScore += 1
            }
            if choice.opponent == "✂️" {
                output = "You win yayyyy"
                score.winScore += 1
            }
        }
        if choice.final == "🗒" {
            if choice.opponent == "🪨" {
                output = "You win yayyyy"
                score.winScore += 1
            }
            if choice.opponent == "🗒" {
                output = "It is a draw"
                score.drawScore += 1
            }
            if choice.opponent == "✂️" {
                output = "You lose wamp wamp" 
                score.loseScore += 1
            }
            
        }
        if choice.final == "✂️" {
            if choice.opponent == "🪨" {
                output = "You lose wamp wamp"
                score.loseScore += 1
            }
            if choice.opponent == "🗒" {
                output = "You win yayyyy"
                score.winScore += 1
            }
            if choice.opponent == "✂️" {
                output = "It is a draw" 
           score.drawScore += 1
            }
        }
        
    }
}
