import SwiftUI
import MapKit
struct ContentView: View {
    let africa = CLLocationCoordinate2D( latitude: 10.0, 
                                         longitude: 30.0)
    let africa1 = CLLocationCoordinate2D( latitude: 20.0, 
                                          longitude: 30.0)
    let africa2 = CLLocationCoordinate2D( latitude: 10.0, 
                                          longitude: 300.0)
    @State var camera: MapCameraPosition = .automatic
    var body: some View {
        VStack {
            Map(position: $camera) {
                Marker("Africa", coordinate: africa)
                    .tint(.blue)
                Annotation("Hello", coordinate: africa1) {
                    Image(systemName: "square.and.arrow.up.fill")                    .padding()
                        .background(.red)
                }
            }
            .mapStyle(.imagery)
          
            .safeAreaInset(edge: .bottom) {    
                HStack{
                    Spacer()
                    Button(action: {
                        camera = .region(MKCoordinateRegion(center: africa1, latitudinalMeters: 200, longitudinalMeters: 200))
                    }, label: {
                        Text("Ok Africa")
                    })
                    Spacer()

                }
                .padding(.bottom)
                .background(.thinMaterial)

            }
            
        } 
    }
}
