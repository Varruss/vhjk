import SwiftUI

struct ContentView: View {
    @State var word = ""
    @State var firstLetter = ""
    @State var lastLetter = ""
    @State var numberOfLetters = ""
    @State var isWordEmpty = ""
    @State var uppercased = ""
    
    @State var find = ""
    @State var replace = ""
    @State var stretch1Answer = ""
    
    @State var definiteArticle = ""
    @State var noun = ""
    @State var verb = ""
    @State var adverb = ""
    
    @State var pigLatinWord = ""
    
    var body: some View {
        VStack {
            Group {
                Divider()
                Text("Strings Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            TextField("Please enter a String", text: $word)
                .textFieldStyle(.roundedBorder)
                .padding()
                .onChange(of: word, perform: { value in
                    //MARK: MVP 
                    
                    numberOfLetters = String(word.count)
                    isWordEmpty = String(word.isEmpty)
                    firstLetter = String(word.first!)
                    lastLetter = String(word.last!)
                    uppercased = word.uppercased()
                    
                    
                })
            Group {
                
                
                Text("MVP")
                    .frame(maxWidth: .infinity, maxHeight: 30)
                    .font(.title)
                    .underline()
                
                HStack {
                    
                    VStack(alignment: .leading) {
                        Text("Number of Letters: ")
                        Text("Is Word Empty: ")
                        Text("First Letter: ")
                        Text("Last Letter: ")
                        Text("All Uppercased: ")
                    }
                    
                    VStack(alignment: .leading)  {
                        Text(numberOfLetters)
                        Text(isWordEmpty)
                        Text(firstLetter)
                        Text(lastLetter)
                        Text(uppercased)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            
            Group {
                Text("Stretch #1")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #1") {
                    //MARK: Stretch #1
                    stretch1Answer = word.replacingOccurrences(of: find, with: replace)                    
                    
                    
                    
                }
                HStack {
                    Text("Replace: ")
                    TextField("letter", text: $find)
                        .autocorrectionDisabled(true)
                    Text(" With: ")
                    TextField("letter", text: $replace)
                        .autocorrectionDisabled(true)
                }
                .textFieldStyle(.roundedBorder)
                .padding()
                
                Text(stretch1Answer)
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
            }
            
            
            Group {
                Text("Stretch #2")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #2") {
                    //MARK: Stretch #2
                    let arrays2 = word.split(separator: " ")
                    definiteArticle = String(arrays2[0])
                    noun = String(arrays2[1])
                    verb = String(arrays2[2])
                    adverb = String(arrays2[3])
                }
                
                HStack {
                    
                    VStack(alignment: .leading) {
                        Text("Definite Article: ")
                        Text("Noun: ")
                        Text("Verb: ")
                        Text("Adverb: ")
                    }
                    
                    VStack(alignment: .leading)  {
                        Text(definiteArticle)
                        Text(noun)
                        Text(verb)
                        Text(adverb)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            
            
            Group {
                Text("Stretch #3")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #3") {
                    //MARK: Stretch #3
                    let word2 = word.lowercased()
                    
                    func pigLatin(word: String) -> String {
                        var newWord = word
                        let startIndex = newWord.startIndex
                        let firstCharacter = newWord[startIndex]
                        newWord.append(firstCharacter)
                        newWord.append("ay")
                        newWord.remove(at: startIndex)
                        return newWord
                    }
                    func simplePigLatin(_ text: String) -> String {
                        let characterSet = CharacterSet.whitespacesAndNewlines.union(.punctuationCharacters)
                        var piggyText = ""
                        var temporaryWord = ""
                        for (index, character) in text.enumerated() {
                            let scalar = character.unicodeScalars.first!
                            if characterSet.contains(scalar) || index == text.count - 1 {
                                if temporaryWord.count > 0 {
                                    let pigLatinWord = pigLatin(word: temporaryWord)
                                    piggyText.append(pigLatinWord)
                                    temporaryWord = ""
                                }
                                
                                if characterSet.contains(scalar) {
                                    piggyText.append(character)
                                }
                            } else {
                                temporaryWord.append(character)
                            }
                        }
                        
                        return piggyText
                    }
                    pigLatinWord = simplePigLatin(word2)
                }
                Text(pigLatinWord)
                    .font(.title)
            }
            
            Spacer()
            Group {
                Image("MobileMakersEduNB")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
            }.padding()
        }
    }
}
