import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            VStack {
                Text("N")
                Image(systemName: "arrow.up")
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundColor(.white)
                Image(systemName: "arrow.down")
                Text("S")
                
            }
            HStack{
                Image(systemName: "arrow.left")
                    .offset(x: -23, y: 0)
            }
            HStack{
                Text("W")
                    .offset(x: -41)
            }
            HStack{
                Image(systemName: "arrow.right")
                .offset(x: 23, y: 0)}
            Text("E")
                .offset(x: 40, y: 0)
            
        }
        ZStack{
            VStack(){
                Image("grandcanyon")
                    .resizable()
                    .frame(width: 200, height: 300)
                    .mask(
                        Circle()
                    )
            }
            VStack{
                Image("grandcanyon")
                    .resizable()
                    .frame(width: 200, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .mask(Circle())
                    .opacity(0.4)
                    .offset(x: 0, y: 250)
            }
            VStack {
                Text("N")
                Image(systemName: "arrow.up")
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundColor(.white)
                Image(systemName: "arrow.down")
                Text("S")
                
                
                HStack{
                    Image(systemName: "arrow.left")
                        .offset(x: -23, y: -60)
                }
                HStack{
                    Text("W")
                        .offset(x: -41, y: -77)
                }
                HStack{
                    Image(systemName: "arrow.right")
                    .offset(x: 23, y: -95)}
                Text("E")
                    .offset(x: 40, y: -112)
                
                
                
            }.offset(x: 0, y: 284)
        }
        ZStack{ 
            VStack{
            Image("grandcanyon")
                .resizable()
                .frame(width: 200, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .mask(Circle())
                .opacity(0.4)
                .offset(x: 0, y: 160)
        }
            VStack {
                Text("N")
                Image(systemName: "arrow.up")
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundColor(.white)
                Image(systemName: "arrow.down")
                Text("S")
                
                
                HStack{
                    Image(systemName: "arrow.left")
                        .offset(x: -23, y: -60)
                }
                HStack{
                    Text("W")
                        .offset(x: -41, y: -77)
                }
                HStack{
                    Image(systemName: "arrow.right")
                    .offset(x: 23, y: -95)
                    
                }
                Text("E")
                    .offset(x: 40, y: -112)
                
                
                
                
            }.offset(x: 0, y: 196)
            Image(systemName: "arrow.up.right")
                .offset(x: 22, y: 139) 
            Image(systemName: "arrow.up.left")
                .offset(x: -22, y: 139) 
            Image(systemName: "arrow.down.left")
                .offset(x: -22, y: 181) 
            Image(systemName: "arrow.down.right")
                .offset(x: 22, y: 181) 
            Text("NW")
                .font(.system(size: 10))
                .offset(x: -40, y: 126)
            Text("NE")
                .font(.system(size: 10))
            .offset(x: 40, y: 126)
            Text("SW")
                .font(.system(size: 10))
            .offset(x: -40, y: 194)
            Text("SE")
                .font(.system(size: 10))
            .offset(x: 40, y: 194)
                
            }
    }
}
