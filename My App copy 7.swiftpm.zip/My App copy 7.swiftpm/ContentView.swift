import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink {
                    Text("Return on Cmoney")
                }
            label: {
                Text("Colin")
            }
            .toolbar {
                Button(action: {
                    
                }, label: {
                    Text("Save")
                })
                Button(action: {
                    
                }, label: {
                    Text("Search")
                })
                Button("Delete") { 
                    
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) { 
                    Text("Home")
                }
                ToolbarItem(placement: .principal) { 
                    Image(systemName: "figure.socialdance")               
                }
                ToolbarItem(placement: .navigationBarLeading) { 
                    Image(systemName: "bus")
                }
            }
            .navigationTitle("Home")
            .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}
