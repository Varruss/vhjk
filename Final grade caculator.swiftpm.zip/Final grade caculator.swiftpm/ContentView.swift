import SwiftUI

struct ContentView: View {
    @State var CG = 0.00
    @State var CGPercent = 0.00
    @State var DG = 0.00
    @State var EPercent = 0.00
    @State var EG = 0.00
    @State var topN = 0.0
    @State var topP = 0.0
    @State var color = true
    @State var ExtraCreditText = ""
    var body: some View {
        ZStack{
            VStack {
                Text("FINAL GRADE CALCULATOR")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .offset(CGSize(width: 0, height: -100))
                Text("Current Grade (%):")
                TextField("", value: $CG, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 50, maxHeight: 50)
                Text("Exam Percentage (%):")
                TextField("", value: $EPercent, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 50, maxHeight: 50)
                Text("Desired Grade (%):")
                TextField("", value: $DG, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 50, maxHeight: 50)
                Text("Calculate")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                    .background(.black)
                    .onTapGesture(perform: {
                        finalEG()
                        RedorGreen()
                        extracredit()
                    })
                Text("Exam Grade:")
                Text("\(EG, specifier: "%.2f")%")
                Text(ExtraCreditText)
                Picker("", selection: $DG) {
                    Text("A").tag(100.00)
                    Text("B").tag(90.00)
                    Text("C").tag(80.00)
                    Text("D").tag(70.00)
                }
                .pickerStyle(.segmented)
                Picker("", selection: $DG) {
                    Text("A").tag(100.00)
                    Text("B").tag(90.00)
                    Text("C").tag(80.00)
                    Text("D").tag(70.00)
                }
                .pickerStyle(.wheel)
            } 
            .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(color ? .green : .red)
    }
    func finalEG() {        
        topP = (1.00 - (EPercent / 100.00))
        topN = (DG - (topP * CG))
        EG = (topN / (EPercent / 100.00))
    }
    func RedorGreen() {
        if EG < 100.00 {
            color = true
        }
        else {
            color = false
        } 
    }
    func extracredit() {
        if EG > 100.00 {
            ExtraCreditText = "You need over 100%, please ask your teacher for extra credit"
        }
    }
}
