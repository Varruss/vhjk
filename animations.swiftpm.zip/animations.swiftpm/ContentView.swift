import SwiftUI

struct ContentView: View {
    @State var isShowing = true
    @State var scale = 1.0
    @State var animationAmount: CGFloat = 1
    @State var xValue: CGFloat = 0
    @State var yValue: CGFloat = 0
    @State var zValue: CGFloat = 0 
    @State var angle: Double = 0
    var body: some View {
        VStack {
            Button(action: {
                isShowing.toggle() 
                scale += 0.5
                withAnimation(.interactiveSpring){ 
                    animationAmount += 360
                }
            }, label: {
                Text("C-Money")
                    .opacity(isShowing ? 1:0)
                    .animation(.easeIn(duration: 1.0), value: isShowing)
                    .frame(width: 200, height: 200)
                    .scaleEffect(scale, anchor: .center)
                
            })
            .background(isShowing ? .red:.blue)
            .animation(.default, value: isShowing)
            .transition(.scale)
            .padding(20)
            .clipShape(Circle())
            .rotation3DEffect(
                .degrees(animationAmount), axis: (x: 0, y: 1, z: 0)
            )
            Text("We miss you more than you know")
                .opacity(isShowing ? 1:0)
                .animation(.easeIn(duration: 1.0), value: isShowing)
        }
        Spacer()
        Text("The Diving Board")
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 50)
            .background(.purple)
            .foregroundColor(.orange)
            .rotation3DEffect(
                Angle(degrees: angle),
                                      axis: (x: xValue, y: yValue, z: zValue)
            )
        Spacer()
        Stepper("angle: \(angle)", value: $angle)
        Stepper("X: \(xValue)", value: $xValue)
        Stepper("Y: \(yValue)", value: $yValue)
        Stepper("Z: \(zValue)", value: $zValue)
        Spacer()
    }
}
