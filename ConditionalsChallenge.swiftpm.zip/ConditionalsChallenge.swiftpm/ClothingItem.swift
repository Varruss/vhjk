import SwiftUI

class ClothingItem {
    var description:String
    var price:Int
    
    init(Description d:String, Price p:Int)
    {
        description = d
        price = p
    }
}
