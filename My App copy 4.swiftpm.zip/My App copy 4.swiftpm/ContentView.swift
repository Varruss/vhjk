import SwiftUI
struct PizzaToppings: Identifiable {
    let id :String = UUID().uuidString
    let name: String
    let count: Int
    
}

class ToppingsViewModel: ObservableObject {
    @Published var toppingsArray: [PizzaToppings] = []
    
    func getToppings() {
        let toppings1 = PizzaToppings(name: "pepperoni", count: 10) 
        let toppings2 = PizzaToppings(name: "sasuage", count: 3) 
        let toppings3 = PizzaToppings(name: "pineapple", count: 43)  
        toppingsArray.append(toppings1)
        toppingsArray.append(toppings2)
        toppingsArray.append(toppings3)
    }
    func deleteToppings(index: IndexSet) {
        toppingsArray.remove(atOffsets: index)
    }
}
struct ContentView: View {
    //  @State var toppingsArray: [PizzaToppings] = []
    @ObservedObject var toppingsViewModel: ToppingsViewModel = ToppingsViewModel()
    var body: some View {
        NavigationView {
            List{
                ForEach(toppingsViewModel.toppingsArray) { toppings in
                    HStack {
                        Text("\(toppings.count)")
                        Text(toppings.name)
                            .font(.headline)
                            .bold()
                    }
                    
                }
                .onDelete(perform: toppingsViewModel.deleteToppings)
            }
            .listStyle(GroupedListStyle())
            .navigationTitle("Toppings List")
            .onAppear {
                toppingsViewModel.getToppings()
            }
        }
    }
}
