import SwiftUI

struct ContentView: View {
    
    @State var mvpText:String = ""
    
    @State var number1 = 0
    @State var number2 = 0
    
    @State var billAmount:Double? = nil
    
    @State var email = ""
    @State var password = ""
    @State var field1Text = ""
    @State var field2Text = ""
    @State var field1Complain = false
    @State var field2Complain = false
    var body: some View {
        VStack {
            Group {
                Divider()
                Text("TextField Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            VStack {
                Text("MVP")
                Divider()
                
                //MARK: MVP
                
                TextField("Enter Your Name", text: $mvpText)
                    .multilineTextAlignment(.center)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 200, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .padding()
                
                
                
                //TODO: MVP, uncomment the line below
                Text(mvpText == "" ? " " : "Hello \(mvpText)")
                
                Divider()
            }
            
            VStack {
                Text("Stretch #1")
                Divider()
                
                //MARK: Stretch #1
                
                HStack{
                    TextField("Enter Number Here", value: $number1, format: .number)
                        .multilineTextAlignment(.center)
                        .keyboardType(.numberPad)                
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .padding()
                    Text("+")
                        .foregroundColor(.black)
                    TextField("Enter Number Here", value: $number2, format: .number)
                        .keyboardType(.numberPad)                
                        .multilineTextAlignment(.center)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    
                        .padding()
                }
                
                
                
                //TODO: Stretch #1, uncomment the line below
                Text("\(number1) + \(number2) = \(number1 + number2)")
                
                Divider()
            }
            
            
            VStack {
                Text("Stretch #2")
                Divider()
                
                //MARK: Stretch #2
                
                TextField("Enter Bill Amount", value: $billAmount, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 300, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .multilineTextAlignment(.center)
                
                
                //TODO: Stretch #2, uncomment the line below
                Text("Your bill is $\(billAmount ?? 0, specifier: "%.2f")")
                
                Divider()
            }
            
            VStack {
                Text("Stretch #3")
                Divider()
                
                //MARK: Stretch #3
                
                TextField("Enter Your Email", text: $email)
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.center)
                SecureField ("Enter Your Password", text: $password)
                     .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.center)
                    .autocorrectionDisabled(/*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
                
                
                
                
                
                
                
                //TODO: Stretch #3, uncomment the lines below
                Button {
                    EmailHelper.shared.sendEmail(subject: "Congratulations!", body: "You completed Stretch #3 on the textfields Challenge. On behalf of MobileMakersEDU, we would like to congratulate you on your great work. Keep it up", to: email, password: password)
                } label: {
                    Text("Send Email")
                        .frame(maxWidth: .infinity, maxHeight: 50)
                        .background(.blue)
                        .foregroundColor(.white)
                        .font(.largeTitle)
                        .clipShape(Capsule())
                }
                
                
                Divider()
            }
            
            VStack {
                Text("Stretch #4")
                Divider()
                
                //MARK: Stretch #4
                HStack{
                    Button(action: {
                        field1Complain = true                     
                    }, label: {
                        TextField("#1", text: $field1Text)
                            .textFieldStyle(.roundedBorder)
                            .multilineTextAlignment(.center)
                            .padding()
                    })
                    .alert(isPresented: $field1Complain){Alert(title: Text(""), message: Text("Use Text Field 2"))
                    }
                    Button(action: {
                        field2Complain = true                     
                    }, label: {
                        TextField("#2", text: $field2Text)
                            .textFieldStyle(.roundedBorder)
                            .multilineTextAlignment(.center)
                            .padding()
                    })
                    .alert(isPresented: $field2Complain){Alert(title: Text(""), message: Text("Use Text Field 1"))
                    }

                }
                
                
                
                
                
                Divider()
            }
            
            Group {
                Spacer()
                Image("mmeLogo")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
            }
            
            
        }
        .frame(maxWidth:.infinity, maxHeight: .infinity)
        .padding(.all)
        .background(Color(red: 0.9, green: 0.9, blue: 0.9))
    }
}
