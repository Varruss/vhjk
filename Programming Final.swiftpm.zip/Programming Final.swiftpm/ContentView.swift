import SwiftUI

struct ContentView: View {
    @State var networth = 0
    @State var networthstr = ""
    @State var assets1 = 0
    @State var assets2 = 0
    @State var assets3 = 0
    @State var liability1 = 0
    @State var liability2 = 0
    @State var liability3 = 0
    @State var showimage = false
    @State var showwealth = false
    @State var broke = false
    var body: some View {
        
        VStack {
            VStack {
                Text("Assets")
                    .bold()
                    .foregroundColor(.green)
                    .font(.title)
                Text("Paycheck")
                TextField("Enter your assets", value: $assets1, format: .number)
                    .frame(width: 50)
                Text("Allowance")
                TextField("Enter your assets", value: $assets2, format: .number)
                    .frame(width: 50)
                Text("Graduation gifts")
                TextField("Enter your assets", value: $assets3, format: .number)
                    .frame(width: 50)
            }
            .multilineTextAlignment(.center)
            .textFieldStyle(.roundedBorder)
            VStack {
                Text("Liability")
                    .bold()
                    .foregroundColor(.red)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                Text("Netflix")
                TextField("Enter your liabilites",  value: $liability1, format: .number)
                    .frame(width: 50)
                Text("Cellphone")
                TextField("Enter your liabilites",  value: $liability2, format: .number)
                    .frame(width: 50)
                Text("Entertainment")
                TextField("Enter your liabilites",  value: $liability3, format: .number)
                    .frame(width: 50)
            }
            .multilineTextAlignment(.center)
            .padding()
            .textFieldStyle(.roundedBorder)
            VStack {
                Button(action: {
                     let assetssum = assets1 + assets2 + assets3
                      let liabilitysum = liability1 + liability2 + liability3
                     networth = assetssum - liabilitysum
                    networthcalc()
                }, label: {
                    Text("Calculate your Networth")
                        .foregroundColor(.blue)
                        .font(.system(size: 20))
                })
                Label("Your Networth is: $\(networth)", systemImage: "dollarsign")
            Text(networthstr)
                if showwealth == true {
                    Image("wealth")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .offset(x: 150, y: -50)
                }
                if broke == true {
                    Image("shack")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .offset(x: 150, y: -50)
                }
                Button(action: {
                    assets1 = 0
                    assets2 = 0
                    assets3 = 0
                    liability1 = 0
                    liability2 = 0
                    liability3 = 0
                    networth = 0
                    showimage.toggle()
                }, label: {
                    Text("CLEAR ALL")
                        .foregroundColor(.red)
                        .font(.system(size: 20))
                })
            }
                if showimage == true {
                    Image("Dog")
                        .resizable()
                        .frame(width: 100, height: 90)
                    Button(action: {
                        showimage.toggle()
                    }, label: {
                        Text("Remove image")
                            .font(.system(size: 15))
                    })
                }
            VStack {
              
            }
        } 
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/,maxHeight: .infinity)
        .background(.black)
    }
    func networthcalc()-> String {
        if networth > 0 {
            networthstr = "You have positive Networth \n                   Like Elon:)"
            showwealth.toggle()
        }
        else if networth < 0 {
            networthstr = "You are broke:("
            broke.toggle()
        }
        else {
            networthstr = "You got equal networth"
        }
        return networthstr
    }
}
