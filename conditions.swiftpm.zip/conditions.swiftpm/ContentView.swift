import SwiftUI

struct ContentView: View {
    var body: some View {
        let name = "wade"
        if (name == "wade") {
        }
    }
    else{
       print(The name is wade) 
    }
    }

