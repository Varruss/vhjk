import SwiftUI
struct ContentView: View {
    var body: some View {
        VStack {
            Text("red")
                .foregroundColor(.red)
            Text("blue")
                .background(.blue)   
            Text("Big")
                .font(.system(size:100))
            Text("Small")
                .font(.system(size:8))
            Text("Left")
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("Right")
                .frame(maxWidth: .infinity, alignment: .trailing)
            Text("Upside Down")
                .rotationEffect(.degrees(180), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Text("Cool Class")
                .font(Font.custom("Zapfino", size:25))
                .background(.black)
            Text("With Blue Border \n Size 10 \n Frame 200 by 200")
                .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .border(Color.blue, width: 10)
                .background(.yellow)
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
            Text("😣")
                .font(.system(size:100))
                .frame(width: 200, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(
                    LinearGradient(gradient: Gradient(colors: [.pink, .purple, .blue]), startPoint: .top, endPoint: .bottom))
        }
        VStack {
            Text("Hello World")
                .font(.system(size:30))
                .foregroundColor(.white)
                .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(.white)
                .background(
                    Image("2Galaxy")
                        .resizable())
        }
    }
}
