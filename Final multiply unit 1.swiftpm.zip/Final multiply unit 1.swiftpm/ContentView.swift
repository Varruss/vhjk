import SwiftUI
struct ContentView: View {
    @State var number1:Double = 0
    @State var number2:Double = 0
    @State var opp = ""
    @State var total = 0
    var body: some View {
        HStack {
            TextField("Enter Number Here", value: $number1, format: .number)
                .multilineTextAlignment(.center)
                .keyboardType(.numberPad)                
                .textFieldStyle(.roundedBorder)
                .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Button(action: {
                if (opp == "+")  {
                    total = Int(number1) + Int(number2)  
                }
                if (opp == "-")  {
                    total = Int(number1) - Int(number2)  
                }
                if (opp == "X" || opp == "*")  {
                    total = Int(number1) * Int(number2)  
                }
                if (opp == "/" || opp == "÷")  {
                    total = Int(number1) / Int(number2)  
                }
                if (opp == "%")
                {
                    total = Int(number1) % Int(number2)
                }
            }, label: {
                TextField("Sign", text: $opp)
                    .multilineTextAlignment(.center)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            })            
            TextField("Enter Number Here", value: $number2, format: .number)
                .multilineTextAlignment(.center)
                .keyboardType(.numberPad)                
                .textFieldStyle(.roundedBorder)
                .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Text("= \(total)")            
        }
        VStack{
            if (total == 64)
            {
                Image("Peach")
                    .resizable()
                    .frame(width: 100, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            }
            else {}
            if (total % 2 == 0 && total != 0 && total != 64) {
                Image("shorse")
                    .resizable()
                    .frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            }
            else  {
                if (total != 0 && total != 64){
                    Image("emailsss") 
                        .resizable()
                        .frame(width: 250, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                }                
            }
            VStack{
                Button(action: {
                    if (opp == "+")  {
                        total = Int(number1) + Int(number2) 
                    }
                    if (opp == "-")  {
                        total = Int(number1) - Int(number2)  
                    }
                    if (opp == "X" || opp == "*")  {
                        total = Int(number1) * Int(number2)  
                    }
                    if (opp == "/" || opp == "÷")  {
                        total = Int(number1) / Int(number2)  
                    }
                    if (opp == "%")
                        {
                        total = Int(number1) % Int(number2)
                    }
                }, label: {
                    Text("CALCULATE")
                })
                .foregroundColor(.white)
                .font(.largeTitle)
                .padding()
            }
        }
        VStack{
            Slider(value: $number1, in: 0...1000, step: 1.0)
            Text("\(number1)")
            Slider(value:$number2, in: 0...1000, step: 1.0)
            Text("\(number2)")
        }    .frame(width: 420, height: 120, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)            
            VStack{
                Button(action: {
                    self.number1 = 0
                    self.number2 = 0
                    self.opp = ""
                    self.total = 0
                }, label: {
                    Text("CLEAR")
                })  
                .foregroundColor(.cyan)
                .font(.title2)
                .padding()
            }
        }
}
