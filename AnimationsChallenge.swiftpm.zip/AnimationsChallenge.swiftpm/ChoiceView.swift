import SwiftUI

//MARK: Stretch #3 

/* Remove the Text below and add any code needed
 * for your personal animation.
 */

struct ChoiceView: View {
    @State var animationAmount = 0.0
    @State var xPosition = 0
    @State var yPosition = 0
    @State var isAnimated = false
    @State var infinite = 0
    
    var body: some View {
        HStack {
            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                .frame(width: isAnimated ? 75: 100, height: isAnimated ? 75: 100)
                .foregroundColor(isAnimated ? .teal: .green)
                .offset(x: isAnimated ? 100: -100, y: 0)
                .rotationEffect(Angle(degrees: isAnimated ? 360: 0))
                .animation(Animation.easeInOut(duration: 1.0).repeatCount( infinite, autoreverses: true), value: isAnimated)
                .onTapGesture(perform: {
                    isAnimated.toggle()
                    if isAnimated == true {
                        infinite = Int.max
                    }
                    else {
                        infinite = 0
                    }
                })
        }
        
    }
}

