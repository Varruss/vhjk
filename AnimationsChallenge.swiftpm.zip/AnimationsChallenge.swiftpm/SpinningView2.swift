import SwiftUI

struct SpinningView2: View {
    
    @State var currentDegree = 0.0
    
    var body: some View {
        Button(action: {
            currentDegree += 360
        }, label: {
            Text("Spins")
                .frame(width: 100, height: 50)
                .background(.blue)
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 10.0))
        })
        //MARK: MVP - Part III
        .rotation3DEffect(
            .degrees(currentDegree),axis: (x: 0.0, y: 1.0, z: 0.0))        .animation(.easeIn, value: currentDegree)
        
        
        
    }
}
