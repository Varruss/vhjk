import SwiftUI

struct RetrieveView: View {
    @State var array: [Double] = []
    @State var name = ""
    @State var age = ""
    @State var phoneNumber = ""

    
    //MARK: MVP - Part III
    @AppStorage("number1") var number1: Int?
    @AppStorage("number2") var number2: String?

    
    
    
    
    //MARK: Stretch #1 - Part III
    @AppStorage("url1") var url1: String?  
    @AppStorage("url2") var url2: String?

    
    
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Group {
                TitleView(name: "MVP")
                HStack {
                    Text("Number1: ")
                    //TODO: MVP
                    Text("\(number1 ?? 0)")
                }
                HStack {
                    Text("Number2: ")
                    Text("\(number2 ?? "Not Loaded Yet")")
                }
            }
            
            Group {
                TitleView(name: "Stretch #1")
                //TODO: Stretch #1
                Link("Load URL #1", destination: URL(string: url1 ?? "") ?? URL(string: "https://www.apple.com")!)
                Link("Load URL #2", destination: URL(string: url2 ?? "") ?? URL(string: "https://www.apple.com")!)           
            }
           
            Group {
                TitleView(name: "Stretch #2")
                ForEach(array, id: \.self) { value in
                    Text("\(value) ")
                }  
            }
            
            Group {
                TitleView(name: "Stretch #3")
                HStack {
                    Text("Name: ")
                    Text(name)
                }
                HStack {
                    Text("Age: ")
                    Text(age)
                }
                HStack {
                    Text("Phone Number: ")
                    Text(phoneNumber)
                }  
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .font(.title)
        .onAppear(perform: {
            //MARK: MVP - Part IV




            
            //MARK: Stretch #1 - Part IV
            
            
            
            
            //MARK: Stretch #2 - Part II
            
            array = (UserDefaults.standard.array(forKey: "doubleArray") as! [Double]? ?? [])
            
            
            
            //MARK: Stretch #3 - Part III
            var retrievedContacts = Contact(name: name, age: age, phone: phoneNumber)
            if let object = UserDefaults.standard.data(forKey: "Contact") {
                if let objectDecoded = try? JSONDecoder().decode(Contact.self, from: object) as Contact {
                    retrievedContacts = objectDecoded
                }
            } else {
                print("Decoding Failed")
            }
            name = retrievedContacts.name
            age = retrievedContacts.age
            phoneNumber = retrievedContacts.phone
        })
    }
}

