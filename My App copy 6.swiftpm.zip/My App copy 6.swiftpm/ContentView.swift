import SwiftUI

struct ContentView: View {
    // @State var currentUserName: String?
    @AppStorage("name") var currentUserName: String?
    var body: some View {
        VStack(spacing: 20) {
            Text(currentUserName ?? "Add Name Here")
            if let name = currentUserName {
                Text(name)
            }
            Button(action: {
                let name = "Lebron"
                currentUserName = name
             //   UserDefaults.standard.set(name, forKey: "name")
            }, label: {
                Text("Save").textCase(.uppercase)
            })
        }
      //  .onAppear(perform: {
           // currentUserName = UserDefaults.standard.string(forKey: "name")
      //  })
    }
}
