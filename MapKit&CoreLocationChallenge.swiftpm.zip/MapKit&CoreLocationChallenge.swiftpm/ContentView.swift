import SwiftUI
//MARK: MVP - Part I
import MapKit
//extension CLLocationCoordinate2D {
//    static let local: Self = .init(
//        latitude: 42.0791,
//        longitude: -87.9497
//    )
//}
//let rect = MKMapRect(
//    origin: MKMapPoint(.local),
//    size: MKMapSize(width: 0.01, height: 0.01)
// gonna save this for a later date
//)
struct ContentView: View {
    //MARK: MVP - Part II
    
    @State var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 42.0791, longitude: -87.9497), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
    
    //MARK: Stretch #1 - Part II
    @State var waterArray = [Location(coordinates: CLLocationCoordinate2D(latitude: 42.083895790757836, longitude: -87.94915363688276))]
    



    
    var body: some View {
        HeaderView()
            NavigationStack {
                //MARK: MVP - Part III and Stretch #1 - Part III and Stretch #2
                
              
                Map(
                    coordinateRegion: $region,
                    interactionModes: []
                )
                Map(interactionModes: MapInteractionModes.all) {
                    ForEach(waterArray) { location in
                        Marker("Body of Water", coordinate: location.coordinates)
                            .tint(.blue)
                    }
                }
                
                
                
                
                
                Spacer()
                NavigationLink { 
                    //Stretch #3 - Part I
                    Stretch3View(region: region)
    
    
    
                } label: { 
                    Text("Stretch #3")
                        .frame(width: 300, height: 50, alignment: .center)
                        .background(.blue)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
            }
           
        FooterView()
            
    }
}
